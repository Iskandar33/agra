def main():
    ans = factorial(1000)
    print("El valor mínimo para n! es:", ans)
def factorial(n):
   if((n == 0) or (n == 1)):
        resultado = 1
   elif(n > 1):
        resultado = n * factorial(n - 1)
   return resultado

main()
    